package com.fiatx2.orehighlight;

import com.mojang.blaze3d.platform.InputConstants;

import net.minecraft.ChatFormatting;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;

public class OreHighlightClient implements ClientModInitializer {
	public static final String MOD_ID = "orehighlight";

	private static final KeyMapping.Category CATEGORY =
			KeyMapping.Category.register(Identifier.fromNamespaceAndPath(MOD_ID, "main"));

	private static KeyMapping toggleKey;
	private static KeyMapping fullbrightKey;
	private static boolean enabled = false;
	private static boolean fullbright = false;

	public static boolean isEnabled() {
		return enabled;
	}

	@Override
	public void onInitializeClient() {
		toggleKey = KeyMappingHelper.registerKeyMapping(new KeyMapping(
				"key.orehighlight.toggle",
				InputConstants.Type.KEYSYM,
				InputConstants.KEY_F8,
				CATEGORY
		));

		fullbrightKey = KeyMappingHelper.registerKeyMapping(new KeyMapping(
				"key.orehighlight.fullbright",
				InputConstants.Type.KEYSYM,
				InputConstants.KEY_F9,
				CATEGORY
		));

		OreRenderer.init();

		ClientTickEvents.END_CLIENT_TICK.register(OreHighlightClient::onTick);
		ClientLifecycleEvents.CLIENT_STOPPING.register(client -> OreRenderer.close());
	}

	private static void onTick(Minecraft client) {
		while (toggleKey.consumeClick()) {
			enabled = !enabled;
			OreScanner.reset();

			if (!enabled) {
				OreScanner.clear();
			}

			if (client.player != null) {
				client.player.sendSystemMessage(enabled
						? Component.translatable("message.orehighlight.on").withStyle(ChatFormatting.GREEN)
						: Component.translatable("message.orehighlight.off").withStyle(ChatFormatting.RED));
			}
		}

		while (fullbrightKey.consumeClick()) {
			fullbright = !fullbright;

			if (!fullbright && client.player != null) {
				removeFullbright(client.player);
			}

			if (client.player != null) {
				client.player.sendSystemMessage(fullbright
						? Component.translatable("message.orehighlight.fullbright.on").withStyle(ChatFormatting.GREEN)
						: Component.translatable("message.orehighlight.fullbright.off").withStyle(ChatFormatting.RED));
			}
		}

		if (client.player == null || client.level == null) {
			// ออกจากโลกแล้ว -> ล้างข้อมูลเก่า
			OreScanner.clear();
			return;
		}

		if (fullbright) {
			applyFullbright(client.player);
		}

		if (enabled) {
			OreScanner.tick(client);
		}
	}

	/**
	 * Full bright ด้วย Night Vision ฝั่งไคลเอนต์เท่านั้น (ไม่ส่งอะไรไปเซิร์ฟเวอร์)
	 * เติมใหม่ทุก tick ถ้าหาย (เช่น ตอนตาย/เปลี่ยนมิติ)
	 */
	private static void applyFullbright(LocalPlayer player) {
		if (!player.hasEffect(MobEffects.NIGHT_VISION)) {
			player.addEffect(new MobEffectInstance(
					MobEffects.NIGHT_VISION,
					MobEffectInstance.INFINITE_DURATION,
					0,
					false,
					false
			));
		}
	}

	private static void removeFullbright(LocalPlayer player) {
		MobEffectInstance current = player.getEffect(MobEffects.NIGHT_VISION);

		// ลบเฉพาะอันที่ม็อดนี้ใส่ (duration ไม่จำกัด) ไม่ไปลบ Night Vision จริงจากเซิร์ฟเวอร์
		if (current != null && current.isInfiniteDuration()) {
			player.removeEffect(MobEffects.NIGHT_VISION);
		}
	}
}
