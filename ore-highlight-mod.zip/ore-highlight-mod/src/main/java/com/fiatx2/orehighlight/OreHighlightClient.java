package com.fiatx2.orehighlight;

import com.mojang.blaze3d.platform.InputConstants;

import net.minecraft.ChatFormatting;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;

public class OreHighlightClient implements ClientModInitializer {
	public static final String MOD_ID = "orehighlight";

	private static final KeyMapping.Category CATEGORY =
			KeyMapping.Category.register(Identifier.fromNamespaceAndPath(MOD_ID, "main"));

	private static KeyMapping toggleKey;
	private static boolean enabled = false;

	public static boolean isEnabled() {
		return enabled;
	}

	@Override
	public void onInitializeClient() {
		toggleKey = KeyMappingHelper.registerKeyMapping(new KeyMapping(
				"key.orehighlight.toggle",
				InputConstants.Type.KEYSYM,
				InputConstants.KEY_F8,
				CATEGORY
		));

		OreRenderer.init();

		ClientTickEvents.END_CLIENT_TICK.register(OreHighlightClient::onTick);
		ClientLifecycleEvents.CLIENT_STOPPING.register(client -> OreRenderer.close());
	}

	private static void onTick(Minecraft client) {
		while (toggleKey.consumeClick()) {
			enabled = !enabled;
			OreScanner.reset();

			if (!enabled) {
				OreScanner.clear();
			}

			if (client.player != null) {
				client.player.sendSystemMessage(enabled
						? Component.translatable("message.orehighlight.on").withStyle(ChatFormatting.GREEN)
						: Component.translatable("message.orehighlight.off").withStyle(ChatFormatting.RED));
			}
		}

		if (client.player == null || client.level == null) {
			// ออกจากโลกแล้ว -> ล้างข้อมูลเก่า
			OreScanner.clear();
			return;
		}

		if (enabled) {
			OreScanner.tick(client);
		}
	}
}
