package com.fiatx2.orehighlight;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;

import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;

/**
 * สแกนหาแร่รอบตัวผู้เล่น โดยแบ่งงานกระจายหลายๆ tick (ไม่ทำให้เกมกระตุก)
 * รันบน main thread เท่านั้น ส่วนผลลัพธ์ที่ publish เป็น list ที่ไม่เปลี่ยนแปลง (immutable)
 */
public final class OreScanner {
	/** ผลลัพธ์แร่ 1 ก้อน (สี r,g,b ช่วง 0..1) */
	public record Ore(int x, int y, int z, float r, float g, float b) { }

	// ===== ตั้งค่า =====
	/** รัศมีสแกนรอบตัวผู้เล่น (บล็อก) ทั้งแนวนอนและแนวตั้ง */
	private static final int RADIUS = 32;
	/** สแกนกี่แถว (แกน X) ต่อ 1 tick */
	private static final int SLICES_PER_TICK = 6;
	/** จำกัดจำนวนแร่ที่วาดสูงสุด (เก็บอันที่ใกล้ที่สุด) */
	private static final int MAX_ORES = 1500;

	// ===== สีของแร่แต่ละชนิด (RGB) แก้ได้ตามใจ =====
	private static final int COLOR_COAL = 0x3C3C3C;
	private static final int COLOR_IRON = 0xFFB38A;
	private static final int COLOR_COPPER = 0xFF7A1A;
	private static final int COLOR_GOLD = 0xFFD700;
	private static final int COLOR_REDSTONE = 0xFF1A1A;
	private static final int COLOR_LAPIS = 0x2E5BFF;
	private static final int COLOR_DIAMOND = 0x33F2F2;
	private static final int COLOR_EMERALD = 0x1AFF4D;
	private static final int COLOR_QUARTZ = 0xFFFFFF;
	private static final int COLOR_DEBRIS = 0xC040A0;

	private static final int NONE = 0;

	private static volatile List<Ore> published = List.of();

	// state ด้านล่างใช้บน main thread เท่านั้น
	private static final Map<Block, Integer> COLOR_CACHE = new IdentityHashMap<>();
	private static List<Ore> building = new ArrayList<>();
	private static boolean scanning = false;
	private static int centerX, centerY, centerZ, nextX;

	private OreScanner() { }

	public static List<Ore> ores() {
		return published;
	}

	/** เริ่มรอบสแกนใหม่ (ไม่ลบผลเดิมที่โชว์อยู่) */
	public static void reset() {
		scanning = false;
		building = new ArrayList<>();
	}

	/** ลบผลทั้งหมด */
	public static void clear() {
		reset();
		published = List.of();
	}

	public static void tick(Minecraft mc) {
		ClientLevel level = mc.level;
		LocalPlayer player = mc.player;

		if (level == null || player == null) {
			return;
		}

		if (!scanning) {
			centerX = player.getBlockX();
			centerY = player.getBlockY();
			centerZ = player.getBlockZ();
			nextX = centerX - RADIUS;
			building = new ArrayList<>();
			// tag อาจเปลี่ยนตอนเข้าเซิร์ฟเวอร์/รีโหลด datapack -> ล้าง cache ทุกรอบ
			COLOR_CACHE.clear();
			scanning = true;
		}

		int endX = Math.min(nextX + SLICES_PER_TICK - 1, centerX + RADIUS);
		int minY = Math.max(centerY - RADIUS, level.getMinY());
		int maxY = Math.min(centerY + RADIUS, level.getMaxY());

		BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();

		for (int x = nextX; x <= endX; x++) {
			for (int z = centerZ - RADIUS; z <= centerZ + RADIUS; z++) {
				for (int y = minY; y <= maxY; y++) {
					pos.set(x, y, z);
					BlockState state = level.getBlockState(pos);

					if (state.isAir()) {
						continue;
					}

					int color = colorOf(state);

					if (color != NONE) {
						building.add(new Ore(
								x, y, z,
								((color >> 16) & 0xFF) / 255f,
								((color >> 8) & 0xFF) / 255f,
								(color & 0xFF) / 255f
						));
					}
				}
			}
		}

		nextX = endX + 1;

		if (nextX > centerX + RADIUS) {
			finishCycle();
		}
	}

	private static void finishCycle() {
		final int cx = centerX;
		final int cy = centerY;
		final int cz = centerZ;

		building.sort(Comparator.comparingLong(o -> {
			long dx = o.x() - cx;
			long dy = o.y() - cy;
			long dz = o.z() - cz;
			return dx * dx + dy * dy + dz * dz;
		}));

		List<Ore> result = building.size() > MAX_ORES
				? building.subList(0, MAX_ORES)
				: building;

		published = List.copyOf(result);
		building = new ArrayList<>();
		scanning = false;
	}

	private static int colorOf(BlockState state) {
		Block block = state.getBlock();
		Integer cached = COLOR_CACHE.get(block);

		if (cached == null) {
			cached = classify(state);
			COLOR_CACHE.put(block, cached);
		}

		return cached;
	}

	/** เช็กจากชนิดบล็อกตรงๆ (รวมแร่ deepslate และ nether) */
	private static int classify(BlockState state) {
		Block b = state.getBlock();

		if (b == Blocks.DIAMOND_ORE || b == Blocks.DEEPSLATE_DIAMOND_ORE) return COLOR_DIAMOND;
		if (b == Blocks.EMERALD_ORE || b == Blocks.DEEPSLATE_EMERALD_ORE) return COLOR_EMERALD;
		if (b == Blocks.GOLD_ORE || b == Blocks.DEEPSLATE_GOLD_ORE || b == Blocks.NETHER_GOLD_ORE) return COLOR_GOLD;
		if (b == Blocks.IRON_ORE || b == Blocks.DEEPSLATE_IRON_ORE) return COLOR_IRON;
		if (b == Blocks.COPPER_ORE || b == Blocks.DEEPSLATE_COPPER_ORE) return COLOR_COPPER;
		if (b == Blocks.REDSTONE_ORE || b == Blocks.DEEPSLATE_REDSTONE_ORE) return COLOR_REDSTONE;
		if (b == Blocks.LAPIS_ORE || b == Blocks.DEEPSLATE_LAPIS_ORE) return COLOR_LAPIS;
		if (b == Blocks.COAL_ORE || b == Blocks.DEEPSLATE_COAL_ORE) return COLOR_COAL;
		if (b == Blocks.NETHER_QUARTZ_ORE) return COLOR_QUARTZ;
		if (b == Blocks.ANCIENT_DEBRIS) return COLOR_DEBRIS;
		return NONE;
	}
}
