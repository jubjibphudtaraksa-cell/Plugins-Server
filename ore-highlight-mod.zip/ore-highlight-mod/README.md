# Ore Highlight (Fabric, Minecraft 26.2)

กด **F8** เพื่อเปิด/ปิด — โชว์ตำแหน่งแร่ทะลุบล็อกด้วยกล่องสีโปร่งแสง
บล็อกอื่นในโลก **ไม่หาย** เห็นแค่ไฮไลท์เพิ่มขึ้นมาตรงแร่

| แร่ | สี |
|---|---|
| Coal | เทาเข้ม |
| Iron | ส้มอ่อน/ครีม |
| Copper | ส้ม |
| Gold (รวม Nether Gold) | เหลืองทอง |
| Redstone | แดง |
| Lapis | น้ำเงิน |
| Diamond | ฟ้าไซแอน |
| Emerald | เขียว |
| Nether Quartz | ขาว |
| Ancient Debris | ม่วงชมพู |

ครอบคลุมแร่ deepslate ด้วย (ใช้ block tag ของเกม)

## วิธี build

1. ต้องมี **Java 25**
2. โฟลเดอร์นี้ยังไม่มี `gradlew` — สร้างได้โดยรัน `gradle wrapper --gradle-version 9.5.1`
   (หรือก๊อป `gradlew`, `gradlew.bat`, `gradle/wrapper/gradle-wrapper.jar` จาก Fabric example mod)
3. รัน `./gradlew build`
4. ไฟล์ม็อดอยู่ที่ `build/libs/orehighlight-1.0.0.jar`
5. ใส่ใน `mods/` พร้อม **Fabric API 0.161.0+26.2** (หรือใหม่กว่าสำหรับ 26.2)

ถ้า Gradle บอกว่าหา Fabric API/Loader เวอร์ชันนั้นไม่เจอ ให้แก้เลขใน `gradle.properties`

## ปรับแต่ง

- สี: ค่าคงที่ `COLOR_*` ใน `OreScanner.java`
- รัศมีสแกน / จำนวนแร่สูงสุด: `RADIUS`, `MAX_ORES` ใน `OreScanner.java`
- ความโปร่งใส: `ALPHA` ใน `OreRenderer.java`
- เปลี่ยนปุ่ม: ตั้งค่าได้ใน Options > Controls > Key Binds > "Ore Highlight"

## หมายเหตุ

เซิร์ฟเวอร์หลายแห่งนับม็อดแบบนี้เป็น X-ray/โกง ใช้ในเซิร์ฟเวอร์ที่อนุญาตหรือโลกเดี่ยวเท่านั้น
